$(document).ready(function() {
    $('.lightbox').magnificPopup({type:'image'});
  });






